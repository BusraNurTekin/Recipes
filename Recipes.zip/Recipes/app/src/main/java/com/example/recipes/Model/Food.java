package com.example.recipes.Model;

public class Food {
    private int foodId;              //yemek id
    private String nameOfFood;       //yemek adı
    private int typeOfFoodId;        //yemek türü id
    private String[] equipment;      //malzemeler
    private String structure;        //yapılışı
    private String picture;          //yemeğin resmi

public Food(){

}
    public Food(int foodId, String nameOfFood, int typeOfFoodId, String[] equipment, String structure, String picture) {
        this.foodId = foodId;
        this.nameOfFood = nameOfFood;
        this.typeOfFoodId = typeOfFoodId;
        this.equipment = equipment;
        this.structure = structure;
        this.picture = picture;
    }

    public int getFoodId() {
        return foodId;
    }

    public String getNameOfFood() {
        return nameOfFood;
    }

    public int getTypeOfFoodId() {
        return typeOfFoodId;
    }

    public String[] getEquipment() {
        return equipment;
    }

    public String getStructure() {
        return structure;
    }

    public String getPicture() {
        return picture;
    }

    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }

    public void setNameOfFood(String nameOfFood) {
        this.nameOfFood = nameOfFood;
    }

    public void setTypeOfFoodId(int typeOfFoodId) {
        this.typeOfFoodId = typeOfFoodId;
    }

    public void setEquipment(String[] equipment) {
        this.equipment = equipment;
    }

    public void setStructure(String structure) {
        this.structure = structure;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}
