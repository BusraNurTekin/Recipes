package com.example.recipes.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.recipes.Database.DatabaseHelper;
import com.example.recipes.Model.Food;
import com.example.recipes.R;

import java.io.IOException;

public class FoodDetailActivity extends AppCompatActivity {

    LinearLayout equipments;
    ImageView recipePhoto;
    TextView recipeTitle;
    TextView typeName;
    TextView recipe;
    CheckBox cb;

    SQLiteDatabase db;
    DatabaseHelper databaseHelper;

    private void equipmentFill(String[] array) {
        equipments = (LinearLayout) findViewById(R.id.detailEquipments);
        equipments.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < array.length; i++) {
            cb = new CheckBox(this);
            cb.setId(i);
            cb.setText(array[i]);
            equipments.addView(cb);

        }
    }
    public String getTypeName(int id){
        String check = "Select * from Types where id=" + id;
        Cursor c = db.rawQuery(check,null);
        c.moveToFirst();
        String title = " ";
        do{
            title = c.getString(1);

        }while(c.moveToNext());
        c.close();
        return title;
    }

    public Food foodDetail(int id) {
        Food food = new Food();
        String check = "Select * from Foods where foodId=" + id;
        Cursor c = db.rawQuery(check,null);
        c.moveToFirst();

        do{
            food.setStructure(c.getString(4));
            food.setNameOfFood(c.getString(1));
            food.setFoodId(c.getInt(0));
            food.setPicture(c.getString(5));
            food.setTypeOfFoodId(c.getInt(c.getColumnIndex("typeOfFoodId")));

            String[] equipments = c.getString(c.getColumnIndex("equipment")).split(",");
            food.setEquipment(equipments);
            equipmentFill(equipments);


        }while(c.moveToNext());
        c.close();
        return food;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detail);
        int foodId = getIntent().getIntExtra("foodId", 1);

        try {
            databaseHelper = new DatabaseHelper(this);
            db = databaseHelper.getReadableDatabase();

        } catch (IOException e) {

        }
        Food food = foodDetail(foodId);

        equipments = (LinearLayout) findViewById(R.id.detailEquipments);
        recipePhoto = (ImageView) findViewById(R.id.foodPicture);
        recipeTitle = (TextView) findViewById(R.id.detailFoodTitle);
        typeName = (TextView) findViewById(R.id.detailFoodTypeName);
        recipe = (TextView) findViewById(R.id.detailRecipe);

        recipeTitle.setText(food.getNameOfFood());
        recipe.setText(food.getStructure());
        typeName.setText(food.getTypeOfFoodId());
        typeName.setText(getTypeName(food.getTypeOfFoodId()));

        int id = getResources().getIdentifier(food.getPicture(),"drawable",this.getPackageName());
        recipePhoto.setImageResource(id);



    }
}
