package com.example.recipes.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.recipes.Activity.FoodDetailActivity;
import com.example.recipes.Model.Food;
import com.example.recipes.R;

import java.util.ArrayList;

public class FoodAdapter extends BaseAdapter {
    Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Food> foods;

    public FoodAdapter(Activity activity, ArrayList<Food> foods) {
        this.context = activity;
        this.foods = foods;
        this.layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return foods.size();
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        context = parent.getContext();
        View layout = layoutInflater.inflate(R.layout.show_food, null);

        ImageView foodPicture = (ImageView) layout.findViewById(R.id.foodPicture);
        TextView foodName = (TextView) layout.findViewById(R.id.foodName);

        int id = layout.getResources().getIdentifier(foods.get(position).getPicture(),"drawable",context.getPackageName());

        foodPicture.setImageResource(id);

        foodName.setText(foods.get(position).getNameOfFood());

        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(context, FoodDetailActivity.class);
                i.putExtra("foodId",foods.get(position).getFoodId());
                context.startActivity(i);
            }
        });
        return layout;
    }

    @Override
    public Object getItem(int position) {
        return foods.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


}
