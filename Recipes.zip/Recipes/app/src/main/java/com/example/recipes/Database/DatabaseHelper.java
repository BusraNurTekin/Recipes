package com.example.recipes.Database;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class DatabaseHelper {

    private SQLiteDatabase database;
    private DatabaseOpenHelper databaseHelper;


    public DatabaseHelper(Context context){
        databaseHelper = new DatabaseOpenHelper(context, "Recipe", null, 1);
    }

    public void open() throws SQLException{
        database = databaseHelper.getWritableDatabase();
    }

    public void close(){
        if (database != null)
            database.close();
    }

    public void addFood(String name, int typeId, String equipment, String structure, String picture){
        ContentValues newRecipe = new ContentValues();
        newRecipe.put("nameOfFood", name);
        newRecipe.put("typeOfFoodId", typeId);
        newRecipe.put("equipment", equipment);
        newRecipe.put("structure", structure);
        newRecipe.put("picture", picture);
        open();
        database.insert("Foods", null, newRecipe);
        close();
    }

    public void addType(String name){
        ContentValues newType = new ContentValues();
        newType.put("typeName", name);
        open();
        database.insert("Foods", null, newType);
        close();
    }
    public void updateFood(long foodId,String name, int typeId, String equipment, String structure, String picture){
        ContentValues newRecipe = new ContentValues();
        newRecipe.put("nameOfFood", name);
        newRecipe.put("typeOfFoodId", typeId);
        newRecipe.put("equipment", equipment);
        newRecipe.put("structure", structure);
        newRecipe.put("picture", picture);
        open();
        database.update("Food", newRecipe, "foodId=" + foodId, null);
        close();
    }

    public void deleteFood(long foodId){
        open();
        database.delete("Food", "foodId=" + foodId, null);
        close();
    }

    public Cursor getAllFoods(){
        return database.query("Food", new String[] {"foodId", "nameOfFood", "typeOfFoodId"}, null, null, null, null, "name");
    }

    public Cursor getAllType(){
        return database.query("Type", new String[] {"typeId", "typeName"}, null, null, null, null, "name");
    }
    public Cursor getFood(long id){
        return database.query("Food", null, "foodId=" + id, null, null, null, null);
    }

    public Cursor getType(long id){
        return database.query("Type", null, "typeId=" + id, null, null, null, null);
    }


    private class DatabaseOpenHelper extends SQLiteOpenHelper{

        public DatabaseOpenHelper(Context context, String name, CursorFactory factory, int version){
            super(context, name, factory, version);
        }

        public void onCreate(SQLiteDatabase db){
            String sqlFoods = "CREATE TABLE Food" +
                    "(foodId integer primary key autoincrement," +
                    "nameOfFood VARCHAR, typeOfFoodID integer, equipment VARCHAR, structure TEXT," +
                    "picture VARCHAR);";
            db.execSQL(sqlFoods);

            String sqlTypes = "CREATE TABLE Type" +
                    "(typeId integer primary key autoincrement," +
                    "typeName VARCHAR,typePicture VARCHAR);";
            db.execSQL(sqlTypes);

        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        }
    }
}
