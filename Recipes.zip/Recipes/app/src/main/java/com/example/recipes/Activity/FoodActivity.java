package com.example.recipes.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.recipes.Adapter.FoodAdapter;
import com.example.recipes.Database.DatabaseHelper;
import com.example.recipes.Model.Food;
import com.example.recipes.Model.Type;
import com.example.recipes.R;
import java.io.IOException;
import java.util.ArrayList;

public class FoodActivity extends AppCompatActivity {
    ListView listRecipes;
    ArrayList<Food> foods;
    FoodAdapter foodAdapter;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        listRecipes = (ListView) findViewById(R.id.listRecipesId);

        foods = new ArrayList<>();
        int data = getIntent().getIntExtra("type", 1);

        SQLiteDatabase db;
        Cursor c;


        try {
            databaseHelper = new DatabaseHelper(getApplicationContext());
            databaseHelper.createDatabase();
            db = databaseHelper.getReadableDatabase();
            c = db.rawQuery("select * from Foods where typeOfFoodId" + data + "order by foodId desc", null);

            while (c.moveToNext()) {
                int foodId = c.getInt(0);
                String nameOfFood = c.getString(1);
                int typeofFoodId = c.getInt(2);
                String equipment = c.getString(3);
                String structure = c.getString(4);
                String picture = c.getString(5);

                String[] equipments = equipment.split(",");
                foods.add(new Food(foodId, nameOfFood, typeofFoodId, equipments, structure, picture));
            }
        } catch (IOException e) {

        }
        foods = new ArrayList<>();
        foodAdapter = new FoodAdapter(this,foods);

        listRecipes.setAdapter(foodAdapter);

    }
}
