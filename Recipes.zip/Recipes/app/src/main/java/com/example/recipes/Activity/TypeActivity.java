package com.example.recipes.Activity;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.recipes.Adapter.TypeAdapter;
import com.example.recipes.Model.Type;
import com.example.recipes.R;

import java.util.ArrayList;

public class TypeActivity extends AppCompatActivity {
    //Main Activity
    ListView lists;
    ArrayList<Type> typeList;
    TypeAdapter typeAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        typeList = new ArrayList<>();
        typeAdapter = new TypeAdapter(this,typeList);
        lists = (ListView) findViewById(R.id.listId);
        lists.setAdapter(typeAdapter);

    }
}
