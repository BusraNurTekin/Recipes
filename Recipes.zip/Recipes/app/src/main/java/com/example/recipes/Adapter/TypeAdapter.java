package com.example.recipes.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.recipes.Activity.FoodActivity;
import com.example.recipes.Model.Type;
import com.example.recipes.R;
import java.util.ArrayList;

public class TypeAdapter extends BaseAdapter {

    Context context;
    ArrayList<Type> types;
    LayoutInflater layoutInflater;

    public TypeAdapter(Activity activity, ArrayList<Type> types) {
        this.context = activity;
        this.types = types;
    }

    @Override
    public int getCount() {
        return types.size();
    }

    @Override
    public Object getItem(int position) {
        return types.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        context = parent.getContext();
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View showLine = layoutInflater.inflate(R.layout.show_type, null);

        TextView tvTypeTitle = (TextView) showLine.findViewById(R.id.tvTypeTitle);
        ImageView ivTypePicture = (ImageView) showLine.findViewById(R.id.ivTypePicture);

        tvTypeTitle.setText(types.get(position).getTypeName());
        int id = context
                .getApplicationContext()
                .getResources()
                .getIdentifier(
                        types.get(position).getTypePicture(), "drawable", context.getPackageName());
        ivTypePicture.setImageResource(id);

        showLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, FoodActivity.class);
                intent.putExtra("type", types.get(position).getTypeId());
                context.startActivity(intent);
            }
        });
        return showLine;
    }
}
